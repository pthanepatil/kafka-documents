﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.CData.JIRA;
using System.Linq;
using System.Web;

namespace Jira
{

    /// <summary>
    /// Summary description for JiraMethods
    /// </summary>
    public class JiraMethods
    {
        public JiraMethods()
        {
            //
            // TODO: Add constructor logic here
            //
        }

    }
}