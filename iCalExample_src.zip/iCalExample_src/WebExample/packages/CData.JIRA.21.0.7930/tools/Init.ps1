param($installPath, $toolsPath, $package, $project)
[System.Reflection.Assembly]::LoadFile("$($installPath)\lib\net35\System.Data.CData.JIRA.dll")
[System.Data.CData.JIRA.Nuget]::CheckNugetLicense("nuget")