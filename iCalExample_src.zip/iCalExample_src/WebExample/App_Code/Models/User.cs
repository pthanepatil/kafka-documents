﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for User
/// </summary>
public class User
{
    public string UserName = "pThanepatil";
    public string Password = "Globert@123";

    public string ApiToken = "Basic cHRoYW5lcGF0aWxAQWZmaW5pb25EUy5jb206R2xvYmVydEAxMjM=";
    public string UserToken = string.Empty;

    public string ClientIPAddress = string.Empty;
}