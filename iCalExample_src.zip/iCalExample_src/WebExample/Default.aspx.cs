using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net;
using System.Data.CData.JIRA;
using System.Threading.Tasks;
using DDay.iCal;
using Jira.SDK;
using Jira.SDK.Domain;
using System.Text;
using Atlassian.Jira.Linq;
using System.Linq;

public partial class _Default : System.Web.UI.Page
{
    #region Protected Fields

    /// <summary>
    /// The absolute path to the folder that contains our iCalendars
    /// </summary>
    protected string _CalendarAbsPath;
    protected IEnumerable<Occurrence> occurrences;

    protected string baseUrl = "https://jira-staging.cxloyalty.com";
    protected string apiPath = "";


    /// <summary>
    /// A list of calendars that have been loaded from file
    /// </summary>
    protected iCalendarCollection _Calendars = null;

    #endregion

    #region Event Handlers

    protected async void Page_Load(object sender, EventArgs e)
    {
        _CalendarAbsPath = MapPath("~/Calendars");

        GetApiProjects();
        //await UsingJQL();

        if (!IsPostBack)
        {
            //DownloadICSfile(null);

            // Load our list of available calendars
            CalendarList.DataSource = LoadCalendarList();
            CalendarList.DataBind();

            // Select all calendars in the list by default
            foreach (ListItem li in CalendarList.Items)
                li.Selected = true;
        }

        await BindEvents();
    }

    protected void btnDownloadICSfile_Click(object sender, EventArgs e)
    {
        DownloadICSfile(null);
    }

    protected void btnSync_Click(object sender, EventArgs e)
    {
        string stagingJiraUrl = "https://jira-staging.cxloyalty.com/secure/Tempo.jspa#/my-work/timesheet?columns=WORKED_COLUMN&dateDisplayType=days&from=2021-09-01&groupBy=issue&periodType=CURRENT_PERIOD&subPeriodType=MONTH&to=2021-09-30&viewType=TIMESHEET&worker=JIRAUSER26723";
    }

    #endregion

    #region Protected Methods

    /// <summary>
    /// Bind calendar events
    /// </summary>
    /// <returns>
    /// </returns>
    protected async Task BindEvents()
    {
        // Build a list of today's events, and bind our list
        // to the repeater that will display the events.
        occurrences = await GetTodaysEvents();

        TodaysEvents.DataSource = occurrences;
        TodaysEvents.DataBind();

        // Build a list of upcoming events and bind our list
        // to the repeater that will display the events.
        UpcomingEvents.DataSource = GetUpcomingEvents();
        UpcomingEvents.DataBind();
    }

    /// <summary>
    /// Gets a list of iCalendars that are in the "Calendars" directory.
    /// </summary>
    /// <returns>
    /// A list of filenames, without extensions, of the iCalendars 
    /// in the "Calendars" directory
    /// </returns>
    protected IEnumerable<string> LoadCalendarList()
    {
        foreach (string file in Directory.GetFiles(_CalendarAbsPath, "*.ics"))
            yield return Path.GetFileNameWithoutExtension(file);
    }

    /// <summary>
    /// Loads and parses the selected calendars.
    /// </summary>
    protected void LoadSelectedCalendars()
    {
        _Calendars = new iCalendarCollection();
        foreach (ListItem li in CalendarList.Items)
        {
            // Make sure the item is selected
            if (li.Selected)
            {
                // Load the calendar from the file system
                _Calendars.AddRange(iCalendar.LoadFromFile(Path.Combine(_CalendarAbsPath, li.Text + @".ics")));
            }
        }
    }

    /// <summary>
    /// Gets a list of events that occur today.
    /// </summary>
    /// <returns>A list of events that occur today</returns>
    protected async Task<IList<Occurrence>> GetTodaysEvents()
    {
        // Load selected calendars, if we haven't already
        if (_Calendars == null)
            LoadSelectedCalendars();

        // Get all events that occur today.
        IList<Occurrence> occurrences = _Calendars.GetOccurrences<IEvent>(DateTime.Today.AddDays(-1), DateTime.Today);
        
        await CreateWorkLogs(occurrences);

        return occurrences;
    }

    /// <summary>
    /// Gets a list of upcoming events (event that will occur within the
    /// next week).
    /// </summary>
    /// <returns>A list of events that will occur within the next week</returns>
    protected IList<Occurrence> GetUpcomingEvents()
    {
        // Load selected calendars, if we haven't already
        if (_Calendars == null)
            LoadSelectedCalendars();

        return _Calendars.GetOccurrences<IEvent>(DateTime.Today.AddDays(1), DateTime.Today.AddDays(7));
    }

    /// <summary>
    /// Returns a string representation of the start
    /// time of an event.
    /// </summary>
    /// <param name="obj">The event for which to display the start time</param>
    /// <returns>A string representation of the start time of an event</returns>
    protected string GetTimeDisplay(object obj)
    {
        if (obj is Occurrence)
        {
            Occurrence occurrence = (Occurrence)obj;
            IEvent evt = occurrence.Source as IEvent;
            if (evt != null)
            {
                if (evt.IsAllDay)
                    return "All Day";
                else return occurrence.Period.StartTime.Local.ToString("h:mm tt");
            }
        }
        return string.Empty;
    }

    private void DownloadICSfile(string urlPath)
    {
        urlPath = "https://outlook.office365.com/owa/calendar/885ef75e148b41fb8be79551d49f9ca1@tavisca.com/99153f42c68e47c58f1aa8be70287a8610645763331376295934/calendar.ics";
        WebClient webClient = new WebClient();
        byte[] byteArray = webClient.DownloadData(urlPath);
        MemoryStream ms = new MemoryStream(byteArray);

        using (FileStream file = new FileStream(_CalendarAbsPath + "//" + DateTime.Now.Ticks.ToString() + ".ics",
            FileMode.Create, System.IO.FileAccess.Write))
        {
            byte[] bytes = new byte[ms.Length];
            ms.Read(bytes, 0, (int)ms.Length);
            file.Write(bytes, 0, bytes.Length);
            ms.Close();
        }

        //webClient.DownloadFile(filePath, Path.GetFileName(filePath));
    }

    private string GetAccessToken()
    {
        var credentials = UserName + ":" + Password;
        var credentialsBytes = System.Text.Encoding.UTF8.GetBytes(credentials);
        return "Basic " + Convert.ToBase64String(credentialsBytes);
    }

    private WebRequest GetWebRequest(string apiMethod, string queryStringParams = null)
    {
        string apiPath = apiMethod;
        if (!string.IsNullOrEmpty(queryStringParams))
        {
            if (apiPath.Contains("?"))
                apiPath = apiPath + "&" + queryStringParams;
            else if (queryStringParams.Contains("?"))
                apiPath = apiPath + queryStringParams;
            else
                apiPath = apiPath + "?" + queryStringParams;
        }

        WebRequest request = WebRequest.Create(string.Format("{0}/rest/api/2/{1}", baseUrl, apiPath));
        request.Headers.Add("Authorization", GetAccessToken());

        return request;
    }

    private JiraClient GetJiraClient()
    {
        return new JiraClient(baseUrl, UserName, Password);
    }

    private void GetApiProjects()
    {
        try
        {
            //ApiHelper apiHelper = new ApiHelper();
            //apiHelper.BaseUrl = baseUrl;

            //User user = new User();
            //string data = await apiHelper.GetAsync("/rest/api/2/project", user);

            //Using API
            WebRequest request = GetWebRequest("issue/Q1338-1/worklog");
            WebResponse webResponse = request.GetResponse();

            string result = string.Empty;
            using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
            {
                result = reader.ReadToEnd();
            }

            //Using SDK
            JiraClient jira = GetJiraClient();
            var projects = jira.GetProjects();
            var project = jira.GetProject("Q1338");
            var projectRoles = jira.GetProjectRoles("Q1338");
        }
        catch (Exception ex)
        {

        }
    }

    private async Task CreateWorkLogs(IEnumerable<Occurrence> occurrences)
    {
        foreach (Occurrence occurrence in occurrences)
            await CreateWorkLog(occurrence);
    }

    private Dictionary<string, object> GetWorkLogSerialized(Occurrence occurrence)
    {
        IEvent e = (IEvent)occurrence.Source;
        IList<IAttendee> attendee = e.Attendees;

        Dictionary<string, object> postParameters = new Dictionary<string, object>();
        postParameters.Add("timeSpent", Convert.ToString((long)e.Duration.TotalMinutes) + "m");
        postParameters.Add("started", occurrence.Period.StartTime.Date.ToString("yyyy-MM-ddTHH:mm:00.000-0500"));
        postParameters.Add("comment", e.Summary);

        var authorObj = new
        {
            self = "https://jira-staging.cxloyalty.com/rest/api/2/user?username=NBoharapi",
            name = "NBoharapi",
            key = "JIRAUSER26741",
            emailAddress = "Nikhil.Boharapi@tavisca.com",
        };

        postParameters.Add("author", authorObj);


        //postParameters.Add("author.name", "NBoharapi");
        //postParameters.Add("author.key", "JIRAUSER26741");

        return postParameters;
    }

    private Worklog GenerateWorkLogObject(Occurrence occurrence)
    {
        IEvent e = (IEvent)occurrence.Source;

        IList<IAttendee> attendee = e.Attendees;

        Worklog worklog = new Worklog();
        worklog.Comment = e.Summary;
        worklog.Started = e.Start.Date;
        worklog.TimeSpentSeconds = (long)e.Duration.TotalSeconds;

        return worklog;
    }

    private Atlassian.Jira.Worklog GetJQLWorkLogObject(Occurrence occurrence)
    {
        IEvent e = (IEvent)occurrence.Source;

        //IList<IAttendee> attendee = e.Attendees;

        Atlassian.Jira.Worklog worklog = new Atlassian.Jira.Worklog(e.Duration.TotalSeconds.ToString() + "s", 
            occurrence.Period.StartTime.Date, 
            e.Summary);
        worklog.Author = "NBoharapi";

        return worklog;
    }

    private async Task CreateWorkLog(Occurrence occurrence)
    {
        try
        {
            ////Part 1
            //ApiHelper apiHelper = new ApiHelper();
            //apiHelper.BaseUrl = baseUrl;

            //User user = new User();
            //string data = await apiHelper.PostAsync("/issue/Q1338-1/worklog", GetWorkLogSerialized(occurrence), user);

            ////Part 2
            //WebRequest request = GetWebRequest("issue/Q1338-1/worklog");
            //request.Method = "POST";
            //byte[] byteArray = Encoding.UTF8.GetBytes(GetWorkLogSerialized(occurrence).Serialize());
            //request.ContentType = "application/json";
            //request.ContentLength = byteArray.Length;

            //using (Stream requestStream = request.GetRequestStream())
            //{
            //    requestStream.Write(byteArray, 0, byteArray.Length);
            //}
            //var response = request.GetResponse();

            ////Part 3
            await UsingJQL(occurrence);

            //JiraClient jira = GetJiraClient();
            //var issue = jira.GetIssue("Q1338-1");
            //var issues = jira.GetIssuesFromProjectVersion("Q1338", "None");

            //Worklog worklog = GenerateWorkLogObject(occurrence);
            ////worklog.Issue = issue;
            //issue.GetWorklogs();



        }
        catch (Exception ex) { }
    }

    //Using ODBC connection
    private static void GetJiraProjects()
    {
        string connectionString = "APIToken=Basic cHRoYW5lcGF0aWxAQWZmaW5pb25EUy5jb206R2xvYmVydEAxMjM=;Url=https://jira-staging.cxloyalty.com/rest";

        using (JIRAConnection conn = new JIRAConnection(connectionString))
        {
            JIRACommand cmd = new JIRACommand("SELECT * FROM Projects", conn);
            JIRADataReader rdr = cmd.ExecuteReader();
            
            DataTable schemaTable = rdr.GetSchemaTable();

            foreach (DataRow row in schemaTable.Rows)
            {
                foreach (DataColumn col in schemaTable.Columns)
                {
                    Console.WriteLine("{0}: {1}", col.ColumnName, row[col]);
                }
            }

            while (rdr.Read())
            {
                int Id = Convert.ToInt32(rdr["Id"]);
            }

            JIRADataAdapter adapter = new JIRADataAdapter("SELECT * FROM Issues", conn);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet);
        }
    }

    private async Task UsingJQL(Occurrence occurrence)
    {
        Atlassian.Jira.Jira jiraConn = Atlassian.Jira.Jira.CreateRestClient(baseUrl, UserName, Password);
        string jqlString = PrepareJqlbyDates("2021-10-01", "2021-10-30");
        
        IEnumerable<Atlassian.Jira.Issue> jiraIssues = await jiraConn.Issues.GetIssuesFromJqlAsync(jqlString, 999);

        foreach (var issue in jiraIssues)
        {
            System.Console.WriteLine(issue.Key.Value + " -- "+ issue.Summary + " -- " + issue.Description);
        }

        var jiraIssue = jiraIssues.ToList().Find(i => i.Key == "Q1338-1");

        Atlassian.Jira.Worklog worklog = GetJQLWorkLogObject(occurrence);


        await jiraIssue.AddWorklogAsync(worklog);
    }

    static string PrepareJqlbyDates(string beginDate, string endDate)
    {
        string jqlString = "project = Q1338"; //issueKey = Q1338-1 AND resolved >= " + beginDate + " AND resolved <= " + endDate;
        return jqlString;
    }

    #endregion

    private string UserName
    {
        get
        {
            return "pthanepatil";
        }
    }

    private string Password
    {
        get
        {
            return "Globert@123";
        }
    }

}