﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AzureAppDelegationSystem.Models.ConfigModels;
using AzureAppDelegationSystem.Service;
using GraphEventRepo.Models;
using GraphEventRepo;
using AzureAppDelegationSystem.Models;

namespace AzureAppDelegationSystem.Controllers
{
    public class GithubWebhookController : Controller
    {
        private GraphConfig graphConfig;
        public GithubWebhookController(GraphConfig graphConfig)
        {
            this.graphConfig = graphConfig;
        }

        [HttpPost]
        public async Task<ActionResult> Notification()
        {
            var event_type = Request.Headers["X-GitHub-Event"];
            //var payload = JSON.parse(request.body)

            using (StreamReader reader = new StreamReader(Request.Body))
            {
                string content = await reader.ReadToEndAsync();

                Events events = new Events();
                events.Content = content;
                events.EventType = event_type.First().ToString();
                events.CreatedDate = DateTimeOffset.Now;
                events.IsProcessed = false;

                WebhookRepo repo = new WebhookRepo();
                repo.SaveEvent(events);

                //return Json("Saved content");


                if (!string.IsNullOrEmpty(content))
                {
                    switch (event_type.First().ToString())
                    {
                        case "push":
                            // Any Git push to a Repository, including editing tags or branches. Commits via               API actions that update references are also counted. This is the default event        

                            //GitPushModel gitPushModel = CommonMethods.Deserialize<GitPushModel>(content);
                            
                            break;

                        case "*":
                            // Any time any event is triggered (Wildcard Event).
                            break;

                        case "commit_comment":
                            // Any time a Commit is commented on.
                            break;

                        case "issues":
                            // Any time an Issue is assigned, unassigned, labeled, unlabeled, opened, closed,              or reopened.
                            break;

                        case "create":
                            // Any time a Branch or Tag is created.
                            break;

                        case "delete":
                            // Any time a Branch or Tag is deleted.
                            break;

                        case "fork":
                            // Any time a Repository is forked.
                            break;

                        case "issue_comment":
                            // Any time an Issue or Pull Request is commented on.
                            break;

                        case "repository":
                            // Any time a Repository is created. Organization hooks only.
                            break;

                        case "team_add":
                            // Any time a team is added or modified on a Repository.
                            break;

                        case "watch":
                            // Any time a User stars a Repository.
                            break;

                        case "page_build":
                            // Any time a Pages site is built or results in a failed build.
                            break;

                        case "release":
                            // Any time a Release is published in a Repository.
                            break;

                        case "pull_request":
                            // Any time a Pull Request is assigned, unassigned, labeled, unlabeled, opened, cl             osed, reopened, or synchronized 
                            break;

                        default:

                            break;

                            //    ApiHelper apiHelper = new ApiHelper();
                            //    apiHelper.BaseUrl = "";
                            //    var callRecords = await apiHelper.GetAsync(apiHelper.BaseUrl + notification.Resource, "", graphService.appAccessToken);
                    }

                    return Json(content);
                }
            }

            return Json("Not implemented!");
        }
    }
}
