﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AzureAppDelegationSystem.Models;
using AzureAppDelegationSystem.Models.ConfigModels;
using AzureAppDelegationSystem.Service;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http.Headers;
using GraphEventRepo.Models;
using GraphEventRepo;
using Azure.Identity;

namespace AzureAppDelegationSystem.Controllers
{
    public class WebhookController : Controller
    {
        private static Dictionary<string, Subscription> Subscriptions = new Dictionary<string, Subscription>();
        private static Timer subscriptionTimer;
        private GraphServiceClient graphServiceClient;
        private GraphConfig graphConfig;

        public string accessToken;

        public WebhookController(GraphConfig graphConfig)
        {
            //this.graphService = graphService;
            this.graphConfig = graphConfig;
        }

        public async Task<IActionResult> CreateSubscriptions()
        {
            string authority = "https://login.microsoftonline.com/childthanepatilyahoo.onmicrosoft.com";
            string resrouce = "https://graph.microsoft.com";

            AuthenticationContext authContext = new AuthenticationContext(authority);

            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("access_token")))
            {
                accessToken = HttpContext.Session.GetString("access_token");

                var options = new TokenCredentialOptions
                {
                    AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
                };

                //graphServiceClient = new GraphServiceClient(new ClientSecretCredential(
                //graphConfig.TenantId, graphConfig.ClientId, graphConfig.ClientSecret, options));

                graphServiceClient = new GraphServiceClient(
                    new DelegateAuthenticationProvider((requestMessage) =>
                    {
                        requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", accessToken);
                        return Task.FromResult(0);
                    }
                    ));

                //var users = await graphServiceClient.Me.Request().GetAsync();

                //User fullUser = await graphServiceClient.Me.Request().Select("MailboxSettings").GetAsync();

                //MailboxSettings mailboxSettings1 = fullUser.MailboxSettings;
                var calevents = await graphServiceClient.Me.Calendar.Events.Request().GetAsync();

                ApiHelper apiHelper = new ApiHelper();
                apiHelper.BaseUrl = graphConfig.Graph_URI + "v1.0/";
                var mailboxSettings = await apiHelper.GetAsync(apiHelper.BaseUrl + "/me/mailboxSettings", "", accessToken);


                //var meetings = await graphServiceClient.Me.OnlineMeetings.Request().GetAsync();

                //var schedules = new List<String>()
                //{
                //    "user1@chlildthanepatilyahoo.onmicrosoft.com"
                //};

                //var startTime = new DateTimeTimeZone
                //{
                //    DateTime = "2019-03-15T09:00:00",
                //    TimeZone = "Pacific Standard Time"
                //};

                //var endTime = new DateTimeTimeZone
                //{
                //    DateTime = "2019-03-15T18:00:00",
                //    TimeZone = "Pacific Standard Time"
                //};

                //var availabilityViewInterval = 60;

                //ICalendarGetScheduleCollectionPage response = await graphServiceClient.Me.Calendar
                //    .GetSchedule(null, endTime, startTime, availabilityViewInterval)
                //    .Request().PostAsync();


            }
            else
                return Redirect("../Home/Index");

            var subscriptions = await graphServiceClient.Subscriptions.Request().GetAsync();

            var sub = new Microsoft.Graph.Subscription();
            sub.ChangeType = "updated";
            sub.NotificationUrl = string.Format("{0}/Webhook/notificationClient", graphConfig.WebhookNotificationUrl);
            sub.Resource = "/me";  //" / communications/callRecords";
            sub.ExpirationDateTime = DateTime.UtcNow.AddMinutes(10);
            sub.ClientState = Guid.NewGuid().ToString();

            //ApiHelper api = new ApiHelper(); api.BaseUrl = "https://graph.microsoft.com";
            //string data = await api.PostAsync("v1.0/subscriptions", sub, null, new AppAccessToken() { access_token = accessToken });

            var newSubscription = await graphServiceClient
                .Subscriptions
                .Request()
                .AddAsync(sub);

            Events events = new Events();
            events.Content = newSubscription.Id;
            events.EventType = "Subscription added";
            events.CreatedDate = DateTimeOffset.Now;
            events.IsProcessed = false;

            WebhookRepo repo = new WebhookRepo();
            repo.SaveEvent(events);


            Subscriptions[newSubscription.Id] = newSubscription;

            if (subscriptionTimer == null)
            {
                subscriptionTimer = new Timer(CheckSubscriptions, null, 5000, 15000);
            }

            return null;
        }


        public async Task<ActionResult> notificationClient([FromQuery] string validationToken = null)
        {
            // handle validation
            if (!string.IsNullOrEmpty(validationToken))
            {
                Console.WriteLine($"Received Token: '{validationToken}'");

                Events events = new Events();
                events.Content = validationToken;
                events.EventType = "validation token";
                events.CreatedDate = DateTimeOffset.Now;
                events.IsProcessed = false;

                WebhookRepo repo = new WebhookRepo();
                repo.SaveEvent(events);

                return Ok(validationToken);
            }

            if (!string.IsNullOrEmpty(HttpContext.Session.GetString("access_token")))
            {
                accessToken = HttpContext.Session.GetString("access_token");

                graphServiceClient = new GraphServiceClient(
                    new DelegateAuthenticationProvider((requestMessage) =>
                    {
                        requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", accessToken);
                        return Task.FromResult(0);
                    }
                    ));
            }

            using (StreamReader reader = new StreamReader(Request.Body))
            {
                string content = await reader.ReadToEndAsync();

                if (!string.IsNullOrEmpty(content))
                {
                    Console.WriteLine(content);

                    var notifications = content.Deserialize<NotificationResponse>();

                    foreach (var notification in notifications.Items)
                    {
                        Console.WriteLine($"Received notification: '{notification.Resource}', {notification.ResourceData?.Id}");

                        Events events = new Events();
                        events.Content = content;
                        events.EventType = notification.Resource;
                        events.CreatedDate = DateTimeOffset.Now;
                        events.IsProcessed = false;

                        WebhookRepo repo = new WebhookRepo();
                        repo.SaveEvent(events);

                        //ApiHelper apiHelper = new ApiHelper();
                        //apiHelper.BaseUrl = graphConfig.Graph_URI + "v1.0/";
                        //var callRecords = await apiHelper.GetAsync(apiHelper.BaseUrl + notification.Resource, "", accessToken);
                    }
                }
            }

            return null;
        }


        private void CheckSubscriptions(Object stateInfo)
        {
            AutoResetEvent autoEvent = (AutoResetEvent)stateInfo;

            Console.WriteLine($"Checking subscriptions {DateTime.Now.ToString("h:mm:ss.fff")}");
            Console.WriteLine($"Current subscription count {Subscriptions.Count()}");

            foreach (var subscription in Subscriptions)
            {
                // if the subscription expires in the next 2 min, renew it
                if (subscription.Value.ExpirationDateTime < DateTime.UtcNow.AddMinutes(2))
                {
                    RenewSubscription(subscription.Value);
                }
            }
        }

        private async void RenewSubscription(Subscription subscription)
        {
            Console.WriteLine($"Current subscription: {subscription.Id}, Expiration: {subscription.ExpirationDateTime}");

            var newSubscription = new Subscription
            {
                ExpirationDateTime = DateTime.UtcNow.AddMinutes(5)
            };

            await graphServiceClient
              .Subscriptions[subscription.Id]
              .Request()
              .UpdateAsync(newSubscription);

            subscription.ExpirationDateTime = newSubscription.ExpirationDateTime;
            Console.WriteLine($"Renewed subscription: {subscription.Id}, New Expiration: {subscription.ExpirationDateTime}");
        }
    }
}
