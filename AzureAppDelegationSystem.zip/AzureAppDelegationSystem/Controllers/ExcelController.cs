﻿using AzureAppDelegationSystem.Models;
using AzureAppDelegationSystem.Models.ConfigModels;
using AzureAppDelegationSystem.Service;
using GraphEventRepo;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Controllers
{
    public class ExcelController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IConfiguration _configuration;
        public ExcelController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;

        }

        public async Task<IActionResult> Index()
        {
            var model = ExcelHelper.ExecuteDataSet<ExcelMapper>("SELECT name, emp_id, designation, join_date From [Employee Details$]");
            
            return Json(model);
        }

    }
}
