﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Controllers
{
    public class AWSController : Controller
    {
        public ActionResult ParseJson()
        {
            string jsonString = "{\"eventID\":\"c8198e93-80a8-4027-bfbf-7770594a28ac\",\"awsRegion\":\"us-east-1\",\"eventVersion\":\"1.08\",\"responseElements\":\"{\\\"ConsoleLogin\\\":\\\"Success\\\"}\",\"sourceIPAddress\":\"204.155.123.94\",\"userAgent\":\"Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36\",\"userIdentity\":{\"type\":\"AssumedRole\",\"principalId\":\"AROA2UXI5O3UV3FFU7WNX:RFord@affinionds.com\",\"arn\":\"arn:aws:sts::731706652393:assumed-role/adfs-connect-use1/RFord@affinionds.com\",\"accountId\":\"731706652393\"},\"eventType\":\"AwsConsoleSignIn\",\"eventTime\":\"2022-02-18T14:04:52\",\"eventName\":\"ConsoleLogin\",\"recipientAccountId\":\"731706652393\",\"additionalEventData\":\"{\\\"LoginTo\\\":\\\"https://us-east-1.console.aws.amazon.com/connect/federate/f804b7a6-2996-464f-a6f2-e398ba89a1c5?destination\\=%2Fconnect%2Fccp-v2\\\",\\\"MobileVersion\\\":\\\"No\\\",\\\"MFAUsed\\\":\\\"No\\\",\\\"SamlProviderArn\\\":\\\"arn:aws:iam::731706652393:saml-provider/ADFS\\\"}\",\"managementEvent\":true,\"resources\":[],\"readOnly\":false}";

            return null;
        }
    }
}
