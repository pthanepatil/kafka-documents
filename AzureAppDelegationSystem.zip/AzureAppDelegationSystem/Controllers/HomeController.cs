﻿using AzureAppDelegationSystem.Models;
using AzureAppDelegationSystem.Models.ConfigModels;
using AzureAppDelegationSystem.Service;
using GraphEventRepo;
using GraphEventRepo.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IConfiguration _configuration;
        public GraphServiceClient graphServiceClient = null;
        private GraphConfig _graphConfig;

        //private readonly ITokenAcquisition _tokenAcquisition;

        private string auth_uri = "https://login.microsoftonline.com/{0}/oauth2/v2.0/authorize";
        private string token_uri = "https://login.microsoftonline.com/{0}/oauth2/v2.0/token";
        private string admin_uri = "https://login.microsoftonline.com/common/adminconsent";

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration, GraphConfig graphConfig)
        {
            _logger = logger;
            //_tokenAcquisition = tokenAcquisition;
            _configuration = configuration;
            _graphConfig = graphConfig;

        }

        public async Task<IActionResult> Index()
        {
            string Url = string.Format(auth_uri, _configuration["AzureAD:TenantId"]) + string.Format("?client_id={0}&response_type=code&redirect_uri={1}&scope={2}", _configuration["AzureAD:ClientId"]
                , _graphConfig.WebhookNotificationUrl + _configuration["AzureAD:AuthCodeRedirectUrl"], _configuration["AzureAD:Scopes"]);

            return Redirect(Url);

            #region SDK call

            //var newToken = new TokenAcquisitionOptions();
            //newToken.ForceRefresh = true;

            //var token = await _tokenAcquisition.GetAuthenticationResultForUserAsync(new string[] { ".default" });

            //GraphServiceClient graphServiceClient = new GraphServiceClient("https://graph.microsoft.com/v1.0",
            //    new DelegateAuthenticationProvider(
            //        request =>
            //        {
            //            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("bearer", token.AccessToken);

            //            return Task.CompletedTask;
            //        }
            //        ));

            //var userList = graphServiceClient.Users.Request().Select(x => x.DisplayName).GetAsync().Result;

            #endregion

            return View();
        }

        public async Task<IActionResult> AuthCode(string code, string token_type, string expires_in, string access_token, string refresh_token)
        {
            string Url = string.Format(token_uri, _configuration["AzureAD:TenantId"]);
            
            List<KeyValuePair<string, string>> keyValuePairs = new List<KeyValuePair<string, string>>();
            keyValuePairs.Add(new KeyValuePair<string, string>("grant_type", "authorization_code"));
            keyValuePairs.Add(new KeyValuePair<string, string>("code", code));
            keyValuePairs.Add(new KeyValuePair<string, string>("client_id", _configuration["AzureAD:ClientId"]));
            keyValuePairs.Add(new KeyValuePair<string, string>("client_secret", _configuration["AzureAD:ClientSecret"]));
            keyValuePairs.Add(new KeyValuePair<string, string>("scope", _configuration["AzureAD:Scopes"]));
            keyValuePairs.Add(new KeyValuePair<string, string>("redirect_uri", _graphConfig.WebhookNotificationUrl + "/Home/AuthCode"));
                        
            ApiHelper api = new ApiHelper(); api.BaseUrl = "https://login.microsoftonline.com";
            string data = await api.PostAsync(Url, null, keyValuePairs, null);
            AppAccessToken appAccessToken = data.Deserialize<AppAccessToken>();

            HttpContext.Session.SetString("access_token", appAccessToken.access_token);
            HttpContext.Session.SetString("refresh_token", appAccessToken.refresh_token);

            Events events = new Events();
            events.Content = appAccessToken.refresh_token;
            events.EventType = "Refresh Token";
            events.CreatedDate = DateTime.Now;

            WebhookRepo repo = new WebhookRepo();
            repo.SaveEvent(events);

            //return Redirect(_graphConfig.WebhookNotificationUrl + "/Home/TokenRedirect");
            return Redirect(_graphConfig.WebhookNotificationUrl + "/Webhook/CreateSubscriptions");
        }

        [HttpGet]
        public async Task<IActionResult> RefreshToken(string grant_type, string code, string client_id, string client_secret, string scope)
        {
            //string Url = token_uri;
            //string queryParams = string.Format("?grant_type=refresh_token&code={0}&client_id={1}&client_secret={2}&scope={3}&redirect_uri={4}"
            //    , code, client_id, client_secret, _configuration["AzureAD:Scopes"], _graphConfig.WebhookNotificationUrl + _configuration["AzureAD:TokenRedirectUrl"]);

            //return null;

            string Url = string.Format(token_uri, _configuration["AzureAD:TenantId"]);
            string refreshToken = HttpContext.Session.GetString("refresh_token");

            List <KeyValuePair<string, string>> keyValuePairs = new List<KeyValuePair<string, string>>();
            keyValuePairs.Add(new KeyValuePair<string, string>("client_id", _configuration["AzureAD:ClientId"]));
            keyValuePairs.Add(new KeyValuePair<string, string>("client_secret", _configuration["AzureAD:ClientSecret"]));
            keyValuePairs.Add(new KeyValuePair<string, string>("scope", ".default"));
            keyValuePairs.Add(new KeyValuePair<string, string>("refresh_token", refreshToken));
            keyValuePairs.Add(new KeyValuePair<string, string>("grant_type", "refresh_token"));
            keyValuePairs.Add(new KeyValuePair<string, string>("redirect_uri", _graphConfig.WebhookNotificationUrl + "/Home/RefreshToken"));

            ApiHelper api = new ApiHelper(); api.BaseUrl = "https://login.microsoftonline.com";
            string data = await api.PostAsync(Url, null, keyValuePairs, null);
            AppAccessToken appAccessToken = data.Deserialize<AppAccessToken>();

            Events events = new Events();
            events.Content = appAccessToken.refresh_token;
            events.EventType = "Refresh Token";
            events.CreatedDate = DateTime.Now;

            WebhookRepo repo = new WebhookRepo();
            repo.SaveEvent(events);

            return Json("New Token");
        }

        public async Task<IActionResult> signout()
        {
            var user = HttpContext.User;
            if (user?.Identity.IsAuthenticated == true)
            {
                // delete local authentication cookie
                await HttpContext.SignOutAsync();

                //return Redirect("https://login.microsoftonline.com/common/oauth2/v2.0/logout");

                return SignOut(new AuthenticationProperties { RedirectUri = "https://login.microsoftonline.com/common/oauth2/v2.0/logout",  });

                // raise the logout event
                //await _events.RaiseAsync(new UserLogoutSuccessEvent(user.GetSubjectId(), user.GetName()));
            }

            return Json("");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
