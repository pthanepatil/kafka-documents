﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace AzureAppDelegationSystem.Models
{
    public class ExcelMapper
    {
        public string name { get; set; }
        public string emp_id { get; set; }
        public string designation { get; set; }
        public DateTime join_date { get; set; }
    }
}
