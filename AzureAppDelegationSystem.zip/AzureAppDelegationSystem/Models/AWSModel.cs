﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Models
{
    public class AWSModel
    {
        public string eventID { get; set; }
        public string awsRegion { get; set; }
        public float eventVersion { get; set; }
        public ResponseElements responseElements { get; set; }
        public string sourceIPAddress { get; set; }
        public string userAgent { get; set; }
        public List<AWSUserIdentity> userIdentity { get; set; }
        
        public string eventType { get; set; }
        public DateTime eventTime { get; set; }
        public string eventName { get; set; }

        public string recipientAccountId { get; set; }
        public string additionalEventData { get; set; }
        public bool managementEvent { get; set; }
        public string resources { get; set; }
        public bool readOnly { get; set; }
    }

    public class ResponseElements
    {
        public string ConsoleLogin { get; set; }
    }

    public class AWSUserIdentity
    {
        public string type { get; set; }
        public string principalId { get; set; }
        public string arn { get; set; }
        public string accountId { get; set; }
    }
}
