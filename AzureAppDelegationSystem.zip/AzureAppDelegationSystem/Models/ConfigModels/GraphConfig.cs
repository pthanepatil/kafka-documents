﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Models.ConfigModels
{
    public class GraphConfig
    {
        public string AADInstance { get; set; }
        public string Graph_URI { get; set; }
        public string Domain { get; set; }
        public string Scopes { get; set; }
        public string[] Scope
        {
            get { return Scopes.Split(','); }
        }

        public string TenantId { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string WebhookNotificationUrl { get; set; }
    }
}
