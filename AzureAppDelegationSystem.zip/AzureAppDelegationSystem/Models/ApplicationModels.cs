﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebhookAPI.Models
{
    public class ApplicationModels
    {
    }

    public class AppCredentials
    {
        public string client_id;
        public string client_secret;
        public string grant_type;
        public string scope;
    }

    public class AppAccessToken
    {
        public string token_type;
        public int expires_in;
        public DateTimeOffset ExpiresOn;
        public string access_token;
    }
}
