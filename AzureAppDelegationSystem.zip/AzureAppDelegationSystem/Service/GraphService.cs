﻿using Azure.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using AzureAppDelegationSystem.Models;
using AzureAppDelegationSystem.Models.ConfigModels;

namespace AzureAppDelegationSystem.Service
{
    public class GraphService
    {
        public AppAccessToken appAccessToken = null;
        public GraphServiceClient graphServiceClient = null;

        public GraphService(AppAccessToken appAccessToken)
        {
            //var param = new AppCredentials()
            //{
            //    client_id = clientId,
            //    client_secret = clientSecret,
            //    grant_type = "client_credentials",
            //    scope = "https://graph.microsoft.com/.default"
            //};

            //AppAccessToken appAccessToken = await new ApiHelper().GetGraphTokenAsync(tenantId, param);


            //var options = new TokenCredentialOptions
            //{
            //    AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            //};

            //var clientSecretCredential = new ClientSecretCredential(
            //    graphConfig.TenantId, graphConfig.ClientId, graphConfig.ClientSecret, options);

            //var token = clientSecretCredential.GetToken(new Azure.Core.TokenRequestContext(graphConfig.Scope));

            //appAccessToken = new AppAccessToken()
            //{
            //    access_token = token.access_token,
            //    expires_in = token.
            //};

            string authority = "https://login.microsoftonline.com/adfei.onmicrosoft.com";
            string resrouce = "https://graph.microsoft.com";

            AuthenticationContext authContext = new AuthenticationContext(authority);


            graphServiceClient = new GraphServiceClient(
                new DelegateAuthenticationProvider((requestMessage) =>
                {
                    requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", appAccessToken.access_token);
                    return Task.FromResult(0);
                }
                ));

        }
    }
}
