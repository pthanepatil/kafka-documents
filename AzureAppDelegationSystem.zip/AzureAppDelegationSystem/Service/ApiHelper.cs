﻿using AzureAppDelegationSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Service
{
    public class ApiHelper
    {
        public string BaseUrl { get; set; }

        public async Task<string> GetGraphCodeAsync(string tenantId, string queryStringParams)
        {
            string apiResult = string.Empty;
            string apiPath = string.Format("https://login.microsoftonline.com/{0}/oauth2/v2.0/authorize", tenantId);

            if (!string.IsNullOrEmpty(queryStringParams))
            {
                //queryStringParams = System.Web.HttpUtility.UrlEncode(queryStringParams);
                if (apiPath.Contains("?"))
                    apiPath = apiPath + "&" + queryStringParams;
                else if (queryStringParams.Contains("?"))
                    apiPath = apiPath + queryStringParams;
                else
                    apiPath = apiPath + "?" + queryStringParams;
            }

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://login.microsoftonline.com");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpContent content = new StringContent("");
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                HttpResponseMessage httpResponse = await client.PostAsync(apiPath, content);

                if (httpResponse.IsSuccessStatusCode)
                {
                    apiResult = httpResponse.Content.ReadAsStringAsync().Result;
                }
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP GET API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <returns></returns>
        public async Task<T> GetAsync<T>(string apiPath, string queryStringParams, string access_token)
        {
            T apiResult = default(T);

            if (!string.IsNullOrEmpty(queryStringParams))
            {
                if (apiPath.Contains("?"))
                    apiPath = apiPath + "&" + queryStringParams;
                else if (queryStringParams.Contains("?"))
                    apiPath = apiPath + queryStringParams;
                else
                    apiPath = apiPath + "?" + queryStringParams;
            }

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (!string.IsNullOrEmpty(access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer "+ access_token);

                HttpResponseMessage httpResponse = await client.GetAsync(apiPath);
                if (httpResponse.IsSuccessStatusCode)
                {
                    string result = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResult = result.Deserialize<T>();
                }
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP GET API Helper
        /// Which returns string
        /// </summary>     
        /// <param name="apiPath"></param>
        /// <returns></returns>
        public async Task<string> GetAsync(string apiPath, string queryStringParams, string access_token)
        {
            string apiResult = string.Empty;

            if (!string.IsNullOrEmpty(queryStringParams))
            {
                if (apiPath.Contains("?"))
                    apiPath = apiPath + "&" + queryStringParams;
                else if (queryStringParams.Contains("?"))
                    apiPath = apiPath + queryStringParams;
                else
                    apiPath = apiPath + "?" + queryStringParams;
            }

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (!string.IsNullOrEmpty(access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access_token);

                HttpResponseMessage httpResponse = await client.GetAsync(apiPath);

                if (httpResponse.IsSuccessStatusCode)
                {
                    apiResult = httpResponse.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    string statusCode = httpResponse.StatusCode.ToString();
                    string content = await httpResponse.Content.ReadAsStringAsync();
                }
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP GET API Helper without user token requirement
        /// specifically created for the static data pull methods
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<T> GetAsync<T>(string apiPath, AppAccessToken access)
        {
            return await GetAsync<T>(apiPath, string.Empty, access.access_token);
        }

        /// <summary>
        /// HTTP GET API Helper without user token requirement
        /// specifically created for the static data pull methods
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<string> GetAsync(string apiPath, string access_token)
        {
            return await GetAsync(apiPath, string.Empty, access_token);
        }

        /// <summary>
        /// HTTP POST API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <param name="jsonStr"></param>
        /// <returns></returns>
        public async Task<T> PostAsync<T>(string apiPath, object requestData, AppAccessToken access)
        {
            T apiResult = default(T);
            string jsonStr = requestData.Serialize();

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (access != null && !string.IsNullOrEmpty(access.access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

                HttpContent content = new StringContent(jsonStr);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage httpResponse = await client.PostAsync(apiPath, content);
                if (httpResponse.IsSuccessStatusCode)
                {
                    string result = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResult = result.Deserialize<T>();
                }
                //TODO: What if IsSuccessStatusCode is FALSE
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP POST API Helper
        /// </summary>       
        /// <param name="apiPath"></param>
        /// <param name="jsonStr"></param>
        /// <returns></returns>
        public async Task<string> PostAsync(string apiPath, object requestData, List<KeyValuePair<string,string>> keyValuePairs, AppAccessToken access)
        {
            string apiResult = string.Empty;
            string jsonStr = requestData.Serialize();

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(BaseUrl);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            if (access != null && !string.IsNullOrEmpty(access.access_token))
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

            HttpContent content;
            if (keyValuePairs != null)
            {
                content = new FormUrlEncodedContent(keyValuePairs);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
            }
            else
            {
                content = new StringContent(requestData.Serialize());
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            }

            var httpResponse = await client.PostAsync(apiPath, content);
            if (httpResponse.IsSuccessStatusCode)
            {
                apiResult = await httpResponse.Content.ReadAsStringAsync();
            }
            //TODO: What if IsSuccessStatusCode is FALSE

            client.Dispose();

            return apiResult;
        }

        /// <summary>
        /// HTTP POST API Helper along with timeout to cancel operation after specified time
        /// </summary>
        /// <param name="apiPath"></param>
        /// <param name="requestData"></param>
        /// <param name="timeout"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public async Task<T> PostAsync<T>(string apiPath, object requestData, TimeSpan timeout, AppAccessToken access)
        {
            T apiResult = default(T);
            string jsonStr = requestData.Serialize();

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (access != null && !string.IsNullOrEmpty(access.access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

                HttpContent content = new StringContent(jsonStr);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
                cancellationTokenSource.CancelAfter(timeout);
                Task<HttpResponseMessage> task = client.PostAsync(apiPath, content, cancellationTokenSource.Token);

                try
                {
                    HttpResponseMessage httpResponse = await task;
                    if (httpResponse.IsSuccessStatusCode)
                    {
                        string result = httpResponse.Content.ReadAsStringAsync().Result;
                        apiResult = result.Deserialize<T>();
                    }
                }
                catch
                {
                }
                //TODO: What if IsSuccessStatusCode is FALSE
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP POST API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <param name="jsonStr"></param>
        /// <returns></returns>
        //public async string PostAsync(string apiPath, object requestData, User user)
        //{
        //    T apiResult = default(T);
        //    string jsonStr = requestData.Serialize();

        //    using (HttpClient client = new HttpClient())
        //    {
        //        client.BaseAddress = new Uri(BaseUrl);
        //        client.DefaultRequestHeaders.Accept.Clear();
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //        if (user != null && !string.IsNullOrEmpty(user.ApiToken))
        //            client.DefaultRequestHeaders.Add("ApiToken", user.ApiToken);
        //        if (user != null && !string.IsNullOrEmpty(user.UserToken))
        //            client.DefaultRequestHeaders.Add("UserToken", user.UserToken);

        //        if (user != null && !string.IsNullOrEmpty(user.ClientIPAddress))
        //            client.DefaultRequestHeaders.Add("ClientIPAddress", user.ClientIPAddress);

        //        HttpContent content = new StringContent(jsonStr);
        //        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        //        HttpResponseMessage httpResponse = await client.PostAsync(apiPath, content);
        //        if (httpResponse.IsSuccessStatusCode)
        //        {
        //            string result = httpResponse.Content.ReadAsStringAsync().Result;

        //        }
        //        //TODO: What if IsSuccessStatusCode is FALSE
        //    }
        //    return apiResult;
        //}

        /// <summary>
        /// HTTP DELETE API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <returns></returns>
        public async Task<T> DeleteAsync<T>(string apiPath, string queryStringParams, AppAccessToken access)
        {
            T apiResult = default(T);

            if (queryStringParams != null)
            {
                if (apiPath.Contains("?"))
                    apiPath = apiPath + "&" + queryStringParams;
                else if (queryStringParams.Contains("?"))
                    apiPath = apiPath + queryStringParams;
                else
                    apiPath = apiPath + "?" + queryStringParams;
            }

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (access != null && !string.IsNullOrEmpty(access.access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

                HttpResponseMessage httpResponse = await client.DeleteAsync(apiPath);
                if (httpResponse.IsSuccessStatusCode)
                {
                    string result = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResult = result.Deserialize<T>();
                }
            }
            return apiResult;
        }

        /// <summary>
        /// HTTP DELETE API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <returns></returns>
        public async Task<string> DeleteAsync(string apiPath, string queryStringParams, AppAccessToken access)
        {
            string apiResult = string.Empty;

            if (queryStringParams != null)
            {
                if (apiPath.Contains("?"))
                    apiPath = apiPath + "&" + queryStringParams;
                else if (queryStringParams.Contains("?"))
                    apiPath = apiPath + queryStringParams;
                else
                    apiPath = apiPath + "?" + queryStringParams;
            }

            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (access != null && !string.IsNullOrEmpty(access.access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

                HttpResponseMessage httpResponse = await client.DeleteAsync(apiPath);
                if (httpResponse.IsSuccessStatusCode)
                {
                    apiResult = httpResponse.Content.ReadAsStringAsync().Result;
                }
            }
            return apiResult;
        }

        /// <summary>
        ///HTTP PUT API Helper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="apiPath"></param>
        /// <param name="jsonStr"></param>
        /// <returns></returns>
        public async Task<T> PutAsync<T>(string apiPath, object RequestData, AppAccessToken access)
        {
            T apiResult = default(T);
            string jsonStr = RequestData.Serialize();
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (access != null && !string.IsNullOrEmpty(access.access_token))
                    client.DefaultRequestHeaders.Add("Authorization", "Bearer " + access.access_token);

                HttpContent content = new StringContent(jsonStr);
                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
                HttpResponseMessage httpResponse = await client.PutAsync(apiPath, content);
                if (httpResponse.IsSuccessStatusCode)
                {
                    string result = httpResponse.Content.ReadAsStringAsync().Result;
                    apiResult = result.Deserialize<T>();
                }
            }
            return apiResult;
        }

        ///// <summary>
        /////HTTP PUT API Helper
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="apiPath"></param>
        ///// <param name="jsonStr"></param>
        ///// <returns></returns>
        //public async Task<string> PutAsync(string apiPath, object RequestData, User user)
        //{
        //    string apiResult = string.Empty;
        //    string jsonStr = RequestData.Serialize();
        //    using (HttpClient client = new HttpClient())
        //    {
        //        client.BaseAddress = new Uri(BaseUrl);
        //        client.DefaultRequestHeaders.Accept.Clear();
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        //        if (user != null && !string.IsNullOrEmpty(user.ApiToken))
        //            client.DefaultRequestHeaders.Add("ApiToken", user.ApiToken);
        //        if (user != null && !string.IsNullOrEmpty(user.UserToken))
        //            client.DefaultRequestHeaders.Add("UserToken", user.UserToken);

        //        if (user != null && !string.IsNullOrEmpty(user.ClientIPAddress))
        //            client.DefaultRequestHeaders.Add("ClientIPAddress", user.ClientIPAddress);

        //        HttpContent content = new StringContent(jsonStr);
        //        content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
        //        HttpResponseMessage httpResponse = await client.PutAsync(apiPath, content);
        //        if (httpResponse.IsSuccessStatusCode)
        //        {
        //            apiResult = httpResponse.Content.ReadAsStringAsync().Result;
        //        }
        //    }
        //    return apiResult;
        //}

        //public async Task<T> GetObject<T>(string URLPostFix, string QueryStringParams, object RequestData, string HTTPMethod)
        //{
        //    string strURLPost = URLPostFix;

        //    if (URLPostFix.Contains("?"))
        //        strURLPost = strURLPost + "&" + QueryStringParams;
        //    else
        //        strURLPost = strURLPost + "?" + QueryStringParams;

        //    using (HttpClient client = new HttpClient())
        //    {
        //        client.BaseAddress = new Uri(BaseUrl);
        //        //client.DefaultRequestHeaders.Add("ApiToken", ApiToken);
        //        //client.DefaultRequestHeaders.Add("UserToken", user);
        //        HttpResponseMessage httpResp;

        //        httpResp = await client.PostAsJsonAsync(strURLPost, RequestData);

        //        string msg = await httpResp.Content.ReadAsStringAsync();
        //        return await httpResp.Content.ReadAsAsync<T>();
        //    }
        //}

        //public async Task<string> GetString(string URLPostFix, string QueryStringParams, BaseRequest RequestData, string HTTPMethod)
        //{
        //    string response = "";
        //    string strURLPost = URLPostFix;

        //    if (URLPostFix.Contains("?"))
        //        strURLPost = strURLPost + "&" + QueryStringParams;
        //    else
        //        strURLPost = strURLPost + "?" + QueryStringParams;


        //    using (HttpClient client = new HttpClient())
        //    {
        //        client.BaseAddress = new Uri(BaseUrl);
        //        HttpResponseMessage httpResp;
        //        if (RequestData == null)
        //        {
        //            response = await client.GetStringAsync(strURLPost);
        //        }
        //        else
        //        {
        //            StringContent content = new StringContent(RequestData.Serialize());

        //            httpResp = await client.PostAsync(strURLPost, content);
        //            response = await httpResp.Content.ReadAsAsync<string>();
        //        }
        //    }
        //    return response;
        //}
    }
}
