﻿using GraphEventRepo;
using GraphEventRepo.Models;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AzureAppDelegationSystem.Service
{
    public class ExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            Events events = new Events();
            events.Content = context.Exception.Message;
            events.EventType = "Exception filter: ";
            events.CreatedDate = DateTimeOffset.Now;
            events.IsProcessed = false;

            WebhookRepo repo = new WebhookRepo();
            repo.SaveEvent(events);
        }
    }
}
